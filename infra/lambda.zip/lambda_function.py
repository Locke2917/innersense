import json
import boto3
import os

glue = boto3.client("glue")

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))

    # Extract file path from EventBridge event
    file_key = event["detail"]["requestParameters"]["key"]
    bucket_name = event["detail"]["requestParameters"]["bucketName"]
    s3_path = f"s3://{bucket_name}/{file_key}"

    print(f"Starting Glue job with input file: {s3_path}")

    # Trigger Glue job
    response = glue.start_job_run(
        JobName=os.environ["GLUE_JOB_NAME"],
        Arguments={"--input_path": s3_path}
    )

    print("Glue job started:", response["JobRunId"])
    return response