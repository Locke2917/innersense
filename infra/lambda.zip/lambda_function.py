import boto3
import os
import json
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

glue_client = boto3.client("glue")

def lambda_handler(event, context):
    logger.info("🚀 Lambda triggered! Event received: %s", json.dumps(event, indent=2))

    # Extract the uploaded file path from the S3 event
    records = event.get("Records", [])
    if not records:
        logger.error("❌ No S3 records found in event!")
        return {"statusCode": 400, "body": "No S3 records found"}

    s3_record = records[0]  # Assume one file at a time
    bucket_name = s3_record["s3"]["bucket"]["name"]
    object_key = s3_record["s3"]["object"]["key"]

    # Construct the full S3 path
    input_path = f"s3://{bucket_name}/{object_key}"
    logger.info(f"📌 Extracted input_path: {input_path}")

    job_name = os.getenv("GLUE_JOB_NAME")

    try:
        response = glue_client.start_job_run(
            JobName=job_name,
            Arguments={"--input_path": input_path}  # Pass the file path dynamically
        )
        logger.info(f"🔥 Glue job started successfully: {response['JobRunId']}")
    except Exception as e:
        logger.error(f"❌ Glue job failed to start: {str(e)}")

    return {
        "statusCode": 200,
        "body": json.dumps(f"Glue job started: {response.get('JobRunId', 'N/A')} with input_path: {input_path}")
    }
